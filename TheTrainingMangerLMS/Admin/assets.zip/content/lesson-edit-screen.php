<?php

	if (!isset($lesson)) {
		ttp_lms_error("Lesson not set for Admin Course Builder Lesson Edit Screen.");
	}
?>
<style>
#edit-lesson-screen label {
	display: block;
	padding-left: 0.1em;
	font-size: larger;
}
#edit-lesson-screen .input-block {
	padding-top: 0.25em;
	padding-bottom: 0.75em;
}
</style>
<div id="edit-lesson-screen" style="width: 100%; height: 100%;">
	<form id="edit-lesson-form">
		<input type="hidden" name="ID" value=""/>
		<div class="input-block">
			<label for="title">Name</label>
			<input id="title" type="text" name="title" size="50" value=""/>
		</div>
		<div class="input-block">
			<label for="description">Description</label>
			<?php wp_editor("", "description", array('textarea_rows' => 5, 'media_buttons' => false)); ?>
		</div>
		<div class="input-block">
			<label for="content">Content</label>
			<?php wp_editor("", "content", array('textarea_rows' => 10, 'media_buttons' => false)); ?>
		</div>
		<div class="input-block">
			<label for="estimated_time">Estimated Time (hours)</label>
			<input id="estimated_time" type="number" name="estimated_time" size="4" value=""/>
		</div>
		<div style="float:right; padding: 2em;">
			<input type="button" value="Submit"/>
			<input type="button" value="Cancel"/>
		</div>
	</form>
</div>
