jQuery(document).ajaxStart(function() {
    jQuery('body').css('cursor', 'wait');
}).ajaxComplete(function() {
    jQuery('body').css('cursor', 'default');
});

function updateCourseBuilder() {
	jQuery.ajax({
		type: "POST",
		url: ajaxurl, 
		data: {
			action: 'ttp_lms_admin_coursebuilder',
			data: jQuery('#form-content').serialize(),
			nonce: thetrainingpartnerslms.nonce
		},
		success: function( response ) {
			processResponse( response );
		},
		statusCode: {
			401: function(jqXHR, textStatus, errorThrown) {
				alert(textStatus);
			},
			420: function(jqXHR, textStatus, errorThrown) {
				alert(textStatus);
			},
		},
		error: function(jqXHR, textStatus, errorThrown) {
			if (textStatus !== 'error') {
				// have them try again or refresh the browser

			}
			alert(jQuery.parseJSON(jqXHR.responseText).errors[0]);
		}
	});
}

function processResponse( response ) {
	if (response.success == false) {
		alert("The response was not succesful!");
	}
	//thetrainingpartnerslms.nonce = response.nonce;
}
