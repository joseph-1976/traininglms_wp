(function($, undefined) {
$.widget( "ttp.table", {
	defaultElement: "<table>",
	options: {
		scrollable: false,
		columns_resizable: false,
		width: 'available',
		height: 'pack_or_inherit'
		//resize_columns: false,
		//This would be for a record source or a table record source
		//filterable: false,
		//pageable: false,
		//load_source:
		//load_method:autofill vs pageable vs all
	},
	_getWidth: function(e) {
		return $(e).outerWidth();
	},
	_setWidth: function(e, outer) {
		var e$ = $(e);
		var width = outer - (e$.outerWidth() - e$.width());
		e$.width(width);
	},
	_getColumnsDescriptor: function(selector) {
		var that = this;
		var trow = $(this.element).find(selector);
		if (!trow.length) return null;
		var col_desc = {};
		col_desc.widths = trow.children().map(
			function(i, e) { return that._getWidth(e); }
		).get();
		// these will always be calculated, but we need the array in place to start with
		var temp = [], i = col_desc.widths.length;
		while(i--) { temp[i] = col_desc.widths[i]; }
		col_desc.scaled_widths = temp; col_desc.resized_widths = [];
		return col_desc;
	},
	/* From jquery-ui-menu
	_hasScroll: function() {
		return this.element.outerHeight() < this.element.prop( "scrollHeight" );
	}, */
	// on refresh, remove scroll, add it back to overflow-y.  Rerun setColumnWidths
	_setColumnWidths: function(widths) {
			var that = this;
			// set normal widths in thead, tfoot, tbody, browser will adjust widths for the 
			// scroll bar automatically
			$(this.element).find("> tbody tbody").find("tr:first-child").each(
				function(i,e) {
					$(e).children().each(
						function(i,e) {
								that._setWidth(e, widths[i]);
						}
					);
				}
			);
			// if has tbody and rows and has_scroll get widths apply to thead, tfoot and add
			// scrollbarWidth to last column
			var tbody = $(this.element).find("> tbody").get(0);
			this.has_scroll = tbody.offsetHeight < tbody.scrollHeight;
			//if (this.has_scroll) {
			$(this.element).find("> tbody tbody tr:first-child").children().each(
				function(i,e) {
					that.col_desc.scaled_widths[i] = that._getWidth(e);
				}
			);
			$(this.element).find("thead,tfoot").find("tr:first-child").each(
				function(i,e) {
					$(e).children().each(
						function(i,e) {
							if (i != that.col_desc.scaled_widths.length - 1) {
								that._setWidth(e, that.col_desc.scaled_widths[i]);
							} else {
								that._setWidth(e, that.col_desc.scaled_widths[i] + (that.has_scroll ? that.sbwidth : 0) );
							}
						}
					);
				}
			);
			//}
		},
	_setBodyWidth: function(width) {
		// TODO: check the use of _setWidth here
		$(this.element).find("> tbody tbody").width(width + 'px');
		// TODO: scroll bar may dissappear after updating column widths, only if new width is 
		// larger than the original, but for now...
		// set widths for tr of tbody, get has_scroll, then set width of thead,tfoot
		var tbody = $(this.element).find("> tbody").get(0);
		this.has_scroll = tbody.offsetHeight < tbody.scrollHeight;

		$(this.element).find("thead,tfoot").width(width + (this.has_scroll ? this.sbwidth : 0) + 'px');
	},
	_setBodyBounds: function() {
		// $(this.element).find("> tbody").css('top', $(this.element).find("thead").outerHeight() + 'px')
		// Chrome and Firefox use different stock box-sizing for the table element
		// to combat having to look at the box-sizing model for the time being, set display block on tbody first, at which point
		// the table css height becomes valid
		var tbody_height = $(this.element).height() // this.size.height - ($(this.element).outerHeight() - $(this.element).height())
			- $(this.element).find("thead,tfoot").map(
				function(i, e) { 
					return $(e).length ? $(e).outerHeight() : 0; 
				}
			).get().reduce(
				function(prev, current) {
					return prev + current; 
				}, 
				0
			);
		$(this.element).find("tbody").css('height', tbody_height + 'px');
	},
// for now require thead
	_create: function() {
		this.init = false;
		this.sbwidth = jQuery.position.scrollbarWidth();
		if (this.options.scrollable && $(this.element).find("thead tr:first-child").length) {
			// scrollable true = ['x','y'], ['x','y'] = ['x','y'], 'x' = 'x', 'y' = 'y', 
			// get initial column widths before migrating to scrollable
			this.col_desc = this._getColumnsDescriptor("thead tr:first-child");
			//this.size = {'width': $(this.element).width(), 'height': $(this.element).parent().height()}; // .parent() is available
			this.size = {'width': $(this.element).width(), 'height': this.options.height};

			// TODO: Store previous values where necessary for _destroy
			$(this.element).css({'position': 'relative', 'box-sizing': 'border-box', 'display': 'block', 
				'overflow': 'hidden', 'height': this.size.height + 'px'})
			.find("thead").css({'display': 'block', 'position': 'absolute', 'top': '0'}).end()
			.find("tfoot").css({'display': 'block', 'position': 'absolute', 'bottom': '0'}).end()
			// Try to do this in an order such that there is no discernable screen flicker of elements
			// We don't need to do wrapping of tbody if we're only scrolling on the y-axis but for
			// consistency of selectors, we add it regardless.
			//$(this.element).find("thead").outerHeight() + 
			.find("tbody").css('display', 'block').css('position', 'absolute').css('top', '0px')
			//.css('overflow-y', 'none').css('overflow-x', 'none')
			// TODO: fix overflow to support scrollable axis(es)
			.wrap('<tbody style="display: block; position:absolute; overflow: auto; top: ' +
				$(this.element).find("thead").outerHeight() + 'px; width: 100%;"><tr><td style="padding: 0px;">' + 
				'<table style="box-sizing: border-box; display: block; border: 0px none;"></table></td></tr></tbody>');

			// copy classes to nested table
			$(this.element).find("table").attr("class", $(this.element).attr("class"));

			this._setBodyBounds();
			// eventually, we want to replace the above with this
			//$(this.element).layout({type: border, items: {north:{selector: }, south:{selector: }, center: {selector: }}});

			this._setColumnWidths(this.col_desc.widths);
			// add resizable event to table, thead and tfoot to adjust height as needed, should be able to take heights from thead
			// or potentially tbody by removing the scroll bar
			// TODO: export as layout $(this.element).data('akw-layout', this); after implementing layout() and resize();
		}
		if (this.options.columns_resizable && $(this.element).find("thead tr:first-child").length) {
			var that = this;
			// TODO: can do last if scrollable.x
			$(this.element).find("thead tr:first-child").children(':not(:last-child)').each(function(i,e) {
				var params = { handles: 'e' };
				//get corresponding element in tfoot, if it exists
				var temp = $(that.element).find("tfoot > tr > :nth-child(" + (i+1) + ")");
				params['resize'] = function(event, ui) {
					// get difference
					var diff = ui.size.width - ui.originalSize.width;
					var ir = $(ui.element).index();
					// FIXME: if (total_width + diff =< table.width) fall to scrollable.y
					// column widths should not fall below table.width (not outerWidth)
					// but what if we're crossing the threshold, BodyWidth's will need to be set appro-
					// priately
					/*In both cases, we do totals, do this in advance and consider copying to resized_widths
					in the process.  Code can be modified accordingly to support this
					We could potentially short circuit this if diff is positive and the scrollbar is present
					but since we do totals anyway*/
					total = 0;
					for (i = 0; i < that.col_desc.widths.length; i++) {
						total += that.col_desc.widths[i];
					}
					if (total + diff > that.size.width) { // adjust this for sbwidth, when we're in that threshold go back to squeezing them in

						console.log("above");
						console.log(total + ", " + diff + ", " + that.size.width);
					}
					if (that.options.scrollable) {//.x) {
						if (total + diff > that.size.width) {
						total = 0;
						for(i = 0; i < that.col_desc.widths.length; i++) {
							that.col_desc.resized_widths[i] = that.col_desc.widths[i];
							if (i == ir) {
								that.col_desc.resized_widths[i] += diff;
							}
							total += that.col_desc.resized_widths[i];
						}
						that._setBodyWidth(total);
						that._setColumnWidths(that.col_desc.resized_widths);
						return;
						} else {
							// how do we reverse the process correctly?
							// Seems like widths should be set first
							// How can we do this so that widths are not altered?
							Use this.size.width for total (perhaps always)
							// to see if vertical scroll appears
							var tbody = $(that.element).find("> tbody").get(0);
							has_scroll = tbody.offsetWidth < tbody.scrollWidth;
							console.log(has_scroll);
							if (has_scroll) {
								that._setBodyWidth(that.size.width - that.sbwidth);
							//remove it by set widths to max.
							//widths may need adjusting so they add up to total
							}
						}
					}
					// this.options.scrollable.x is false
					// get total width from original widths, excluding item being sized
					var total = 0;
					for(var i = 0; i < that.col_desc.widths.length; i++) {
						if (i != ir) {
							total += that.col_desc.widths[i];
						}
					}
					var scale = (total - diff)/total;
					var total2 = 0;
					for(i = 0; i < that.col_desc.widths.length - 1; i++) {
						if (i != ir) {
							that.col_desc.resized_widths[i] = Math.round(scale * that.col_desc.widths[i]);
						} else {
							that.col_desc.resized_widths[i] = that.col_desc.widths[i] + diff;
						}
						total2 += that.col_desc.resized_widths[i];
					}
					// account for any rounding
					that.col_desc.resized_widths[i] = total - total2;
					that._setColumnWidths(that.col_desc.resized_widths);
					
					/*I say do our own scaling of the original widths with modified size, set them to tbody.tr0
					and copy back the results, the same for what we did originally, and set ui.size.width accordingly
					also take into account min and max
					on stop copy scaled widths to widths
					create option for x extension*/
				};
				params['stop'] = function(event, ui) {
					// copy scaled_width to widths
					for(var i = 0; i < that.col_desc.widths.length; i++) {
						that.col_desc.widths[i] = that.col_desc.resized_widths[i];
					}
				};

				$(e).resizable(params);
			});
			// FIXME: Only add this when the horizontal scroll is present and remove it otherwise.
			$(this.element).find("> tbody").scroll(function(event) {
				var offset = -1 * $(event.target).scrollLeft();
				$(that.element).find("thead,tfoot").css('left', offset + 'px');
			});
		}

		// TODO: add theme classes to the various table components
	},
	refresh: function() {
		this._setColumnWidths(this.col_desc.widths);
		// on refresh we can either reload and place everything (No), but it seems plausible that tbody has changed
		// maybe new_rows or refresh_tbody or refresh_rows
		// to refresh everything be sure to remove overflow-y
		// _setColumnWidths()
	},
	body: function(rows) {
		// get tbody.html(rows);
	}
	// TODO: setOptions or setOption
});

})(jQuery);