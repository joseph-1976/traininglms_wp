/*	@module{name: "jQuery Form Manager"}
		Short description
	@description
		Full description
	@end
*/
var input = $.widget( "aw.input", {
	options: {
/*	@option{name: "name", type: "string", default: "none"}
		The name of the input as used by the form manager.  If undeclared, 
		the name of the input element is used.
	@end
*/
		name: null,
/*	@option{name: "initialValue", type: "varied", default: "none"}
		The initial value for the input.  If undeclared, the current value of 
		the input element is used.
	@end
*/
		initialValue: null;
/*	@option{name: "invalidateClass", type: "string", default: "none"}
		The class added to the input element when validation fails.
	@end
*/
		invalidateClass: null,
/*	@option{name: "validation", type: "function", default: "none"}
		The function used to validate the input element's current value.
*/
		validation: null,

		// event callbacks
/*	@callback{name: "focus", type: "function", default: "none"}
		The function called when the input element gains or loses focus.
	@description
		The function takes the form: function(event, ui) {} where
		ui is a plain object with the the following fields:
			- name:
			- hasFocus: true if the element has gained focus, false otherwise.
	@end
*/
		focus: null,
/*		@callback{name: "change", type: "function", default: "none"}
			The function called when the input element value changes.
		@description
			For text based inputs, change is called when the input loses
			focus and the value has either changed from the value when
			the input gained focus or from the value being set. The
			supplied callback is passed two paramteres; event, ui.
			ui is a plain object with the following fields:
				- element: The jQuery element representing the actual input or the attached widget
				- name: The name as specified in options
				- previousValue: The value either when the input gained focus or set with <value>.
				- changedValue:
		@end
*/
		change: null
	},
	_init: function() {
		throw Error("Input cannot be instantiated directly but must be extended.");
	},
	_create: function() {
		this._super();
        // get __proto__ right before "widget" and use that as interface object
        var base = this;
        while (base.__proto__.widgetName != "widget") {
            base = base.__proto__;
        }
        //if (this != base) { also works
        if (this.widgetFullName != base.widgetFullName) {
            this.element.data(base.widgetFullName, this);
        }
		this.valid = true;
	},
/*	@method{name: "validate"}
		Validates the input's value using the function provided to
		the validation option.
	@params
		This method takes no arguments.
	@description
	@end
*/
	validate: function() {
		if ($.isFunction(this.options.validation)) {
			if (!this.options.validation()) { 
				if ($.isFunction(this.invalidate) { 
					this.invalidate();
				}
			}
		}
	},
/*	@method{name: "isValid"}
		Returns the current validitation state of the input
		as returned by the function supplied in the validation option.
	@returns{type: "boolean"}
		Returns "true" or "false".
	@end
*/
	isValid: function() {
			return this.valid;
	},
/*	@method{name: "reset"}
		Resets the input elements value to the either the initial value
		or the value set with the <value> method and calls the 
		<clear> method.
	@params
		This method takes no arguments.
	@end
*/
	reset: function() { this.clear(); },
/*	@method{name: "clear"}
		Sets the valid state of the input to true and clears the
		invalidateClass option from the input element.  Should be overridden
		in tandem with a custom invalidate method.
	@params
		This method takes no arguments.
	@end
*/
	clear: function() {
		this.valid = true;
		if (typeof this.options.invalidateClass == "string") {
			this.element.removeClass(this.options.invalidateClass); 
		}
	},
/*	@method{name: "invaliate"}
		Sets the valid state to false. If the invalidateClass option is 
		provided, the class is added to the element the widget was attached
		to.  Can be overridden to provide custom invalidation of the input.
	@params
		This method takes no arguments.
	@end
*/
	invalidate: function() {
			this.valid = false;
			if (typeof this.options.invalidateClass == "string") {
				this.element.addClass(this.options.invalidateClass);
			}
	},
/*	@method{name: "hasChanged"}
		Provides the current changed state of the input. Must be overridden 
		in the extended input widget.
	@params
		This method takes no arguments.
	@return{type: "boolean"}
		"true" is the value has changed, "false" otherwise
	@end
*/
	hasChanged: function() { return false; },
/*	@method{name: "value( [value] )"}
		Either sets or gets the value for the input.  If no value is provided,
		returns the current value of the input.  If a value is provided, that
		value is applied to the input.  Must be overridden.
	@params
		@param{type: "varied", optional: true}
			If provided, the value applied to the input.
	@return{type: "varied"}
		If no argument is provided, returns the current value of the input.
	@end
*/
	value: function(value) { if (!undefined value) noopset value else retutn null; }
});

$.widget("aw.inputBasic", $.aw.input, {
	_create: function() {
		_super();
		first find :input(:not(:button:hidden)) maybe make our own list
		var input_filter = "input[type=text],input[type=password],input[type=checkbox],input[type=radio],textarea,select";
		var temp = this.element.filter(input_filter);
		if (temp.length = 0) {
			temp = this.element.find(input_filter);
		}
		if (temp.length = 0) {
			throw Error("No input elements were found.");
		}
		only radio can be plural and must be same name
		if (length > 1) && (temp.filter("[type=radio]").each((function(){ var name = null; return function(i,e){ $(e).name != name;}})
		store type
		get name, if this.options.name is null or undefined then options.name = name;
		if !isNullOrUndefined(this.options.initialValue) this.value(this.options.initialValue);

		if more than one input, throw error (as in different name for radio)
		store type
		get name as in inputName (names may be different) If name is null, use provided, check
		store value if provided, if null, use current value.
		add focus and changed listeners
		for radio buttons, there will probably be two events generated, we need to combine them

		export as aw.input
	},
	invalidate: function() {
		this._super();
		add this._on(this.input, "focusin", function(event) { this.clear(); this._off(this.input, "focusin"); });
	},
	hasChanged: function() {
			switch (this.type) {
				case 'textarea', 'text', 'password': return this.input.val() != this.input.prop("defaultValue");
				case 'select': return !this.input.find("option").filter(function(i,e) { return $(e).prop("selected") && $(e).prop("defaultSelected"); }).length;
				case 'radio': return !this.input.filter(function(i,e) { return $(e).prop("defaultChecked") && $(e).prop("checked"); }).length;
				case 'checkbox': return this.input.prop("defaultChecked") != this.input.prop("checked");
			}
	},
	value: function(value) {
		if (typeof value == 'undefined') {
			// get the value
			switch (this.type) {
				case 'textarea', 'text', 'password': return this.input.val();
				case 'select': return this.input.find("option:selected").val();
				case 'radio': return this.input.filter(":checked").val();
				case 'checkbox': return this.input.prop("checked") ? this.input.val() : ""; // some have recommended undefined
			}
		} else {
			// set the value
			switch (this.type) {
				case 'textarea', 'text', 'password': this.input.val(value); return;
				case 'select': this.input.find("option").each(function(i,e) { $(e).prop("defaultSelected", $(e).val() == value); }).map(function(i,e) { $(e).prop("selected", $(e).val() == value); }); return;
				case 'radio' : this.input.each(function(i,e) { $(e).prop("defaultChecked", $(e).val() == value); }).map(function(i,e) { $(e).prop("checked", $(e).val() == value); }); return;
				case 'checkbox': this.input.prop("defaultChecked", this.input.val() == value).prop("checked", this.input.val() == value); return;
			}
		}
	},
	reset: function() {
		switch(this.type) {
			case 'textarea', 'text', 'password': this.input.val(this.input.prop("defaultValue")); break;
			case 'select' : this.input.find("option").filter(function(i,e) { return $(e).prop("defaultSelected"); }).each(function(i,e) { $(e).prop("selected", true); }); break;
			case 'radio'  : this.input.each(function(i,e) { $(e).prop("checked", $(e).prop("defaultChecked")); }); break;
			case 'checkbox': this.input.prop("checked", this.input.prop("defaultChecked"));
		}
		this.clear();
	},
	disable: function() {
			_super();
		 	this.input.prop("disabled", true);
	},
	enable: function() {
			_super();
			this.input.prop("disabled", false);
	}
});
